# Bộ animation cờ vua

Bộ chuẩn ngày 24/10/2026 gồm 38 PNG trong suốt: 12 `move`, 12 `attack`, 12 `die` và hai hiệu ứng va chạm vàng/tím. Mỗi dải có bốn khung ngang. `idle` dùng khung đầu của `move`, giúp tạo hình không đổi khi chuyển trạng thái.

Đây là bộ asset và thông số phát để triển khai game sau khi hoàn tất báo cáo. Chưa có ứng dụng FastAPI/React hay bộ kiểm tra luật cờ trong thư mục này.

## Cách dùng khi làm frontend

Sao chép toàn bộ nội dung thư mục này vào `public/animations/`. Đọc `manifest.json`; các đường dẫn ảnh tương đối với manifest và dùng tên ASCII: `white/move_knight.png`, `black/attack_rook.png`...

- Khung quân cờ: 320 × 360 px; dải ảnh: 1280 × 360 px. Khung thứ `i` bắt đầu ở x = `i × 320`, y = 0.
- Điểm neo trên bàn cờ: (160,316) trong mỗi khung. Vẽ ảnh tại tọa độ bàn cờ trừ điểm neo, nhân cùng hệ số tỷ lệ cho cả hai.
- `move`: 120 ms/khung, lặp 480 ms. Quỹ đạo trên bàn cờ nội suy bằng `easeInOutCubic`; nhịp lên xuống trong sprite đã được căn lại thành 0/−6/−12/−6 px.
- `attack`: 90/90/80/140 ms, phát một lượt rồi trở về `idle`. Quân tấn công vẫn nguyên vẹn.
- `die`: 140/160/180/200 ms, phát một lượt rồi ẩn quân. Đối với vua, chỉ dùng trạng thái này như hiệu ứng thua trận, không phải nước ăn vua.
- `impact`: bốn khung 320 × 320 px, điểm neo (160,192), thời lượng 40/70/100/160 ms. Chọn màu theo bên tấn công.

## Nhịp ăn quân mẫu

| Thời điểm | Hiển thị |
|---|---|
| 0–360 ms | Di chuyển đến gần ô đích |
| 360 ms | Bắt đầu lấy đà |
| 450 ms | Ra đòn |
| 540 ms | Khung đánh trúng, bật impact và bắt đầu die của quân địch |
| 620 ms | Thu đòn |
| 760 ms | Quân tấn công đứng ở ô đích |
| 1220 ms | Quân địch đã tan, hoàn tất hiệu ứng |

Quân mã có thể thêm cung nhảy cao 0,45 ô. Tốt đi thẳng và ăn chéo. Khi nhập thành, phát hai chuyển động vua/xe đồng thời; bắt tốt qua đường dùng `captureSquare` riêng; phong cấp đổi tạo hình sau khi tới đích. Luật và kết quả nước đi do logic game xác nhận trước, animation chỉ biểu diễn kết quả.

## Bản xem và kiểm tra

- `../../animation-preview/capture-complete/`: GIF liên hoàn của cả hai màu, các bảng khung và `validation.json`.
- `../../asset-source/capture-polish-2026-10-24/generation-spec.json`: prompt và tham chiếu của 19 atlas tạo bằng imagegen tích hợp. Các script tại đó chỉ phân tích tọa độ, đóng gói và dựng bản xem.
- `../../asset-backups/before-capture-polish-2026-10-24/`: ảnh trước lượt hoàn thiện này.

Các PNG tên tiếng Việt ở thư mục `img/trắng/` và `img/đen/` vẫn là bản tương thích kích thước cũ. Khi triển khai mới, dùng bộ chuẩn này để có khung nguyên 320 px và điểm neo thống nhất.
